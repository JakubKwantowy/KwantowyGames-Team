function clock(){
		var time = new Date();
		
		var hour = time.getHours();
		var minute = time.getMinutes();
			if(minute < 10){minute = '0'+minute}
		var seconds = time.getSeconds();
			if(seconds < 10){seconds = '0'+seconds}
		
			document.getElementById('clock').innerHTML = hour+':'+minute+':'+seconds;
			
			setTimeout('clock()',1000);
}